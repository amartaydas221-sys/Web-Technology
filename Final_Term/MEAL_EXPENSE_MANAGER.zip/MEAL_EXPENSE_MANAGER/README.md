# Meal Expense MVC

A lightweight PHP MVC household meal and expense manager. It tracks daily meals, shared expenses, member deposits, household members, and the monthly closing balance.

## Features

- Dashboard with current-month meal, expense, and deposit KPIs
- Daily breakfast, lunch, and dinner logging
- Bazaar, utility, rent, and other expense register
- Member deposit ledger
- Monthly report with printable settlement summary
- MySQL/MariaDB database using the native MySQLi extension
- Responsive layout for desktop and mobile

## XAMPP Setup

1. Install XAMPP with Apache, MySQL, and PHP.
2. Copy this folder to `C:\xampp\htdocs\MEAL_EXPENSE_MANAGER`.
3. Start Apache and MySQL from the XAMPP Control Panel.
4. Open `http://localhost/phpmyadmin` and create a database named `meal_expense_db`.
5. Import `database/schema.sql` into that database.
6. Open `http://localhost/MEAL_EXPENSE_MANAGER/public/`.

The default XAMPP connection is `root` with an empty password. Change the values in `app/config/config.php` if your MySQL account differs.

Set the chef's WhatsApp number in `app/config/config.php` using international format without `+`, spaces, or dashes:

```php
define('CHEF_WHATSAPP', '8801XXXXXXXXX');
```

The dashboard's **Send count to chef via WhatsApp** button opens a pre-filled `wa.me` message containing tomorrow's total meal count.

## Code formatting in VS Code

The workspace has word wrap enabled for PHP, HTML, CSS, and JavaScript. For automatic source formatting, install the PHP Intelephense and Prettier extensions, then use **Format Document** (`Shift+Alt+F`).

### If Apache shows an `Index of /MEAL_EXPENSE_MANAGER` page

Apache is not reading `.htaccess` files. Open `C:\xampp\apache\conf\httpd.conf`, find the `<Directory "C:/xampp/htdocs">` section, and change:

```apache
AllowOverride None
```

to:

```apache
AllowOverride All
```

Save the file and restart Apache from the XAMPP Control Panel. Then use:

```text
http://localhost/MEAL_EXPENSE_MANAGER/
```

The project redirects to its public web root, while the `app` and `database` folders remain blocked from browser access.

## Run locally

For the PHP built-in server instead of XAMPP:

```bash
php -S localhost:8000 -t public
```

Open `http://localhost:8000`.

When XAMPP MySQL is used, the first request creates missing tables and a demo administrator. Demo credentials are `admin@example.com` and `password`.

## MySQL configuration

Optional environment variables can override the XAMPP defaults:

```text
DB_HOST=127.0.0.1
DB_NAME=meal_expense_db
DB_USER=root
DB_PASSWORD=your-password
USE_SQLITE=false
```

The XAMPP application uses MySQLi and the `meal_expense_db` MySQL/MariaDB database.

## Architecture

- `public/index.php` is the front controller.
- `app/core/App.php` dispatches `?url=controller/method` routes.
- Controllers coordinate requests and views.
- Models contain PDO queries.
- `app/views/layouts` contains the shared shell.
- `public/assets` contains the UI styles and small browser behaviors.

## Main routes

- `?url=dashboard`
- `?url=meal`
- `?url=expense`
- `?url=deposit`
- `?url=report`
- `?url=member`
- `?url=auth/login`
