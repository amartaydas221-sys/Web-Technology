<?php

session_start();
require_once dirname(__DIR__) . '/app/config/config.php';
require_once APPROOT . '/config/Database.php';
require_once APPROOT . '/core/Model.php';
require_once APPROOT . '/core/Controller.php';
require_once APPROOT . '/core/App.php';

new App();
