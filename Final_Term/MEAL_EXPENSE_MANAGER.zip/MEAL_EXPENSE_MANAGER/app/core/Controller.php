<?php

class Controller
{
    protected function model(string $model): object
    {
        require_once APPROOT . '/models/' . $model . '.php';
        return new $model();
    }

    protected function view(string $view, array $data = []): void
    {
        extract($data);
        require APPROOT . '/views/' . $view . '.php';
    }

    protected function redirect(string $route): never
    {
        header('Location: ' . APPURL . '/?url=' . ltrim($route, '/'));
        exit;
    }

    protected function requirePost(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('dashboard');
        }
    }

    protected function requireAdmin(): void
    {
        if (($_SESSION['user_role'] ?? '') !== 'admin') {
            $this->redirect('auth/login');
        }
    }

    protected function isAjax(): bool
    {
        return ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';
    }

    protected function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data);
        exit;
    }
}
