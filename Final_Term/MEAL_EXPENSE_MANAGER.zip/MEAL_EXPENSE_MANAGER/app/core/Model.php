<?php

class Model
{
    protected object $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }
}
