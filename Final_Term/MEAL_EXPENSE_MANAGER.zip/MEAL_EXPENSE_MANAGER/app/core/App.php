<?php

class App
{
    private string $controllerName = 'DashboardController';
    private object $controller;
    private string $method = 'index';
    private array $params = [];

    public function __construct()
    {
        $url = $this->parseUrl();
        $controllerName = ucfirst($url[0] ?? 'dashboard') . 'Controller';
        $controllerPath = APPROOT . '/controllers/' . $controllerName . '.php';

        if (file_exists($controllerPath)) {
            $this->controllerName = $controllerName;
            unset($url[0]);
        }

        require_once APPROOT . '/controllers/' . $this->controllerName . '.php';
        $controllerClass = $this->controllerName;
        $this->controller = new $controllerClass();

        if ($this->controllerName !== 'AuthController' && empty($_SESSION['user_id'])) {
            header('Location: ' . APPURL . '/?url=auth/login');
            exit;
        }

        if (isset($url[1]) && method_exists($this->controller, $url[1])) {
            $this->method = $url[1];
            unset($url[1]);
        }

        $this->params = $url ? array_values($url) : [];
        call_user_func_array([$this->controller, $this->method], $this->params);
    }

    private function parseUrl(): array
    {
        $url = filter_input(INPUT_GET, 'url', FILTER_SANITIZE_URL) ?: 'dashboard';
        return array_values(array_filter(explode('/', trim($url, '/'))));
    }
}
