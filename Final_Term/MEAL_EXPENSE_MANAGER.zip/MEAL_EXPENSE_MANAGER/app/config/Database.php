<?php

class Database
{
    private static ?MysqliConnection $instance = null;

    public static function getInstance(): MysqliConnection
    {
        if (self::$instance instanceof MysqliConnection) {
            return self::$instance;
        }

        self::$instance = new MysqliConnection(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
        self::initialize();

        return self::$instance;
    }

    private static function initialize(): void
    {
        $schemaPath = PROJECT_ROOT . '/database/schema.sql';
        self::$instance->multiQuery(file_get_contents($schemaPath));

        if ((int) self::$instance->queryValue('SELECT COUNT(*) FROM months WHERE is_active = 1') === 0) {
            self::$instance->query("INSERT INTO months (label, start_date, end_date, is_active) VALUES (DATE_FORMAT(CURDATE(), '%Y-%m'), DATE_FORMAT(CURDATE(), '%Y-%m-01'), LAST_DAY(CURDATE()), 1)");
        }

        if ((int) self::$instance->queryValue('SELECT COUNT(*) FROM users') === 0) {
            self::$instance->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)')->execute([
                'Admin User',
                'admin@example.com',
                password_hash('password', PASSWORD_DEFAULT),
                'admin',
            ]);
        }
    }
}

class MysqliConnection
{
    private mysqli $connection;

    public function __construct(string $host, string $user, string $password, string $database)
    {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $this->connection = new mysqli($host, $user, $password, $database);
        $this->connection->set_charset('utf8mb4');
    }

    public function prepare(string $sql): MysqliStatement
    {
        return new MysqliStatement($this->connection, $sql);
    }

    public function query(string $sql): mixed
    {
        $result = $this->connection->query($sql);
        return $result instanceof mysqli_result ? new MysqliResult($result) : $result;
    }

    public function queryValue(string $sql): mixed
    {
        return $this->query($sql)->fetchColumn();
    }

    public function multiQuery(string $sql): void
    {
        $this->connection->multi_query($sql);
        while ($this->connection->more_results()) {
            $this->connection->next_result();
        }
    }
}

class MysqliStatement
{
    private mysqli_stmt $statement;
    private array $values = [];

    public function __construct(mysqli $connection, string $sql)
    {
        $this->statement = $connection->prepare($sql);
    }

    public function bindValue(int $position, mixed $value, int $type = 0): void
    {
        $this->values[$position - 1] = $value;
    }

    public function execute(array $values = []): bool
    {
        if ($values !== []) {
            $this->values = $values;
        }

        if ($this->values !== []) {
            $types = str_repeat('s', count($this->values));
            $references = [$types];
            foreach ($this->values as $key => $value) {
                $references[] = &$this->values[$key];
            }
            $this->statement->bind_param(...$references);
        }

        $this->statement->execute();
        return true;
    }

    public function fetch(): ?array
    {
        return $this->result()->fetch();
    }

    public function fetchAll(): array
    {
        return $this->result()->fetchAll();
    }

    public function fetchColumn(): mixed
    {
        return $this->result()->fetchColumn();
    }

    private function result(): MysqliResult
    {
        $result = $this->statement->get_result();
        return new MysqliResult($result);
    }
}

class MysqliResult
{
    public function __construct(private mysqli_result $result) {}

    public function fetch(): ?array
    {
        return $this->result->fetch_assoc() ?: null;
    }

    public function fetchAll(): array
    {
        return $this->result->fetch_all(MYSQLI_ASSOC);
    }

    public function fetchColumn(): mixed
    {
        $row = $this->result->fetch_row();
        return $row[0] ?? null;
    }
}
