<?php

define('APPROOT', dirname(__DIR__));
define('PROJECT_ROOT', dirname(APPROOT));
define('DB_PATH', PROJECT_ROOT . '/database/meal_expense.sqlite');
define('SITENAME', 'Meal Ledger');
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_NAME', getenv('DB_NAME') ?: 'meal_expense_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASSWORD', getenv('DB_PASSWORD') ?: '');
define('USE_SQLITE', filter_var(getenv('USE_SQLITE') ?: 'false', FILTER_VALIDATE_BOOLEAN));
define('CHEF_WHATSAPP', getenv('CHEF_WHATSAPP') ?: '8801875468221');
define('APPURL', rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/'));

date_default_timezone_set('Asia/Dhaka');
