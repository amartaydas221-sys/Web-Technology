<?php

class MemberController extends Controller
{
    public function index(): void
    {
        $this->view('members/index', ['title' => 'Members', 'members' => $this->model('User')->all()]);
    }

    public function save(): void
    {
        $this->requirePost();
        $this->model('User')->create(trim($_POST['name']), trim($_POST['email']), $_POST['password']);
        $this->redirect('member');
    }
}
