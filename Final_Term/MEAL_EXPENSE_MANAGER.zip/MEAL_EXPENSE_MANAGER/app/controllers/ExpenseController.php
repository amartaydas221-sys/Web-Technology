<?php

class ExpenseController extends Controller
{
    public function index(): void
    {
        $this->view('expenses/index', ['title' => 'Expenses', 'members' => $this->model('User')->all(), 'expenses' => $this->model('Expense')->recent(50)]);
    }

    public function save(): void
    {
        $this->requirePost();
        $this->model('Expense')->create([
            'title' => trim($_POST['title']),
            'category' => $_POST['category'],
            'amount' => (float) $_POST['amount'],
            'paid_by' => (int) $_POST['paid_by'],
            'expense_date' => $_POST['expense_date'],
            'note' => trim($_POST['note'] ?? ''),
        ]);
        if ($this->isAjax()) {
            $this->json(['success' => true, 'message' => 'Expense added successfully.']);
        }
        $this->redirect('expense');
    }
}
