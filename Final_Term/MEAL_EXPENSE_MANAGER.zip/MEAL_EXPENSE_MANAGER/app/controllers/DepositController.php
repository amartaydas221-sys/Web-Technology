<?php

class DepositController extends Controller
{
    public function index(): void
    {
        $month = $this->model('Month')->active();
        $expenseTotal = $this->model('Expense')->total($month['start_date'], $month['end_date']);
        $mealTotal = $this->model('Meal')->monthTotal($month['start_date'], $month['end_date']);
        $perMealCost = $mealTotal > 0 ? $expenseTotal / $mealTotal : 0;
        $this->view('deposits/index', [
            'title' => 'Deposits',
            'month' => $month,
            'members' => $this->model('User')->all(),
            'deposits' => $this->model('Deposit')->recent(50),
            'balances' => $this->model('Deposit')->memberBalances(
                $month['start_date'],
                $month['end_date'],
                $perMealCost
            ),
            'perMealCost' => $perMealCost,
            'isAdmin' => ($_SESSION['user_role'] ?? '') === 'admin',
            'currentUserId' => (int) ($_SESSION['user_id'] ?? 0),
        ]);
    }

    public function save(): void
    {
        $this->requirePost();
        $userId = ($_SESSION['user_role'] ?? '') === 'admin' ? (int) $_POST['user_id'] : (int) ($_SESSION['user_id'] ?? 0);
        $amount = (float) ($_POST['amount'] ?? 0);
        if ($userId > 0 && $amount > 0) {
            $this->model('Deposit')->create($userId, $amount, $_POST['deposit_date'], trim($_POST['note'] ?? ''));
            if ($this->isAjax()) {
                $this->json(['success' => true, 'message' => 'Deposit added successfully.']);
            }
        } elseif ($this->isAjax()) {
            $this->json(['success' => false, 'message' => 'Enter a valid deposit amount.'], 422);
        }
        $this->redirect('deposit');
    }
}
