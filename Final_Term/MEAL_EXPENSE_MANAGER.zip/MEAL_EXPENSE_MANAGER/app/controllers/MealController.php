<?php

class MealController extends Controller
{
    public function index(): void
    {
        $this->view('meals/index', [
            'title' => 'Meal sheet',
            'members' => $this->model('User')->all(),
            'meals' => $this->model('Meal')->recent(31),
        ]);
    }

    public function save(): void
    {
        $this->requirePost();
        $this->model('Meal')->save((int) $_POST['user_id'], $_POST['meal_date'], $_POST['meals'] ?? [], trim($_POST['note'] ?? ''));
        if ($this->isAjax()) {
            $this->json(['success' => true, 'message' => 'Meal entry saved successfully.']);
        }
        $this->redirect('meal');
    }

    public function delete(): void
    {
        $this->requirePost();
        $this->requireAdmin();
        $this->model('Meal')->delete((int) ($_POST['id'] ?? 0));
        if ($this->isAjax()) {
            $this->json(['success' => true, 'message' => 'Meal entry removed successfully.']);
        }
        $this->redirect('meal');
    }
}
