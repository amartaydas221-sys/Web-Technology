<?php

class AuthController extends Controller
{
    public function login(): void
    {
        $this->view('auth/login', ['title' => 'Sign in']);
    }

    public function authenticate(): void
    {
        $this->requirePost();
        $user = $this->model('User')->authenticate(trim($_POST['email'] ?? ''), $_POST['password'] ?? '');
        if (!$user) {
            $this->view('auth/login', ['title' => 'Sign in', 'error' => 'The email or password is incorrect.']);
            return;
        }

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role'];
        $this->redirect('dashboard');
    }

    public function logout(): void
    {
        session_destroy();
        $this->redirect('auth/login');
    }
}
