<?php

class DashboardController extends Controller
{
    public function index(): void
    {
        $month = $this->model('Month')->active();
        $expenseModel = $this->model('Expense');
        $depositModel = $this->model('Deposit');
        $mealModel = $this->model('Meal');
        $tomorrow = date('Y-m-d', strtotime('+1 day'));
        $tomorrowMeals = $mealModel->dayTotal($tomorrow);
        $message = "Chef, tomorrow's total meal count is {$tomorrowMeals}. Please prepare meals accordingly. - Meal Ledger";

        $this->view('dashboard/index', [
            'title' => 'Dashboard',
            'month' => $month,
            'tomorrowMeals' => $tomorrowMeals,
            'chefWhatsappUrl' => 'https://wa.me/' . CHEF_WHATSAPP . '?text=' . rawurlencode($message),
            'members' => $this->model('User')->all(),
            'meals' => $mealModel->recent(),
            'expenses' => $expenseModel->recent(),
            'stats' => [
                'meals' => $mealModel->monthTotal($month['start_date'], $month['end_date']),
                'expenses' => $expenseModel->total($month['start_date'], $month['end_date']),
                'deposits' => $depositModel->total($month['start_date'], $month['end_date']),
            ],
        ]);
    }
}
