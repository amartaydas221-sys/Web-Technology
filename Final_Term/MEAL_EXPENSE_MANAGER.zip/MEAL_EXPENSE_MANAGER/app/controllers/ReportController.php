<?php

class ReportController extends Controller
{
    public function index(): void
    {
        $month = $this->model('Month')->active();
        $expenses = $this->model('Expense')->total($month['start_date'], $month['end_date']);
        $deposits = $this->model('Deposit')->total($month['start_date'], $month['end_date']);
        $this->view('reports/index', ['title' => 'Monthly report', 'month' => $month, 'expenses' => $expenses, 'deposits' => $deposits, 'balance' => $deposits - $expenses]);
    }
}
