<?php

class Meal extends Model
{
    public function recent(int $limit = 12): array
    {
        $statement = $this->db->prepare('SELECT meals.*, users.name FROM meals JOIN users ON users.id = meals.user_id ORDER BY meal_date DESC LIMIT ?');
        $statement->bindValue(1, $limit);
        $statement->execute();
        return $statement->fetchAll();
    }

    public function monthTotal(string $startDate, string $endDate): int
    {
        $statement = $this->db->prepare('SELECT COALESCE(SUM(breakfast + lunch + dinner), 0) FROM meals WHERE meal_date BETWEEN ? AND ?');
        $statement->execute([$startDate, $endDate]);
        return (int) $statement->fetchColumn();
    }

    public function dayTotal(string $date): int
    {
        $statement = $this->db->prepare('SELECT COALESCE(SUM(breakfast + lunch + dinner), 0) FROM meals WHERE meal_date = ?');
        $statement->execute([$date]);
        return (int) $statement->fetchColumn();
    }

    public function save(int $userId, string $date, array $meals, string $note = ''): bool
    {
        $values = [$userId, $date, (int) !empty($meals['breakfast']), (int) !empty($meals['lunch']), (int) !empty($meals['dinner']), $note];
        $exists = $this->db->prepare('SELECT id FROM meals WHERE user_id = ? AND meal_date = ? LIMIT 1');
        $exists->execute([$userId, $date]);

        if ($exists->fetchColumn()) {
            $statement = $this->db->prepare('UPDATE meals SET breakfast = ?, lunch = ?, dinner = ?, note = ? WHERE user_id = ? AND meal_date = ?');
            return $statement->execute([$values[2], $values[3], $values[4], $values[5], $userId, $date]);
        }

        $statement = $this->db->prepare('INSERT INTO meals (user_id, meal_date, breakfast, lunch, dinner, note) VALUES (?, ?, ?, ?, ?, ?)');
        return $statement->execute($values);
    }

    public function delete(int $id): bool
    {
        $statement = $this->db->prepare('DELETE FROM meals WHERE id = ?');
        return $statement->execute([$id]);
    }
}
