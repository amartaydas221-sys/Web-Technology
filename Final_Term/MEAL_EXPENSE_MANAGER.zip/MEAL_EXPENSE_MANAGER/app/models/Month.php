<?php

class Month extends Model
{
    public function active(): array
    {
        return $this->db->query('SELECT * FROM months WHERE is_active = 1 ORDER BY start_date DESC LIMIT 1')->fetch() ?: [
            'id' => 0, 'label' => date('Y-m'), 'start_date' => date('Y-m-01'), 'end_date' => date('Y-m-t')
        ];
    }
}
