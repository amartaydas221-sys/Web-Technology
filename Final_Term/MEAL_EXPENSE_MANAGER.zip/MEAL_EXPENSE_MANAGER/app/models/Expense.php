<?php

class Expense extends Model
{
    public function recent(int $limit = 10): array
    {
        $statement = $this->db->prepare('SELECT expenses.*, users.name AS payer FROM expenses JOIN users ON users.id = expenses.paid_by ORDER BY expense_date DESC, expenses.id DESC LIMIT ?');
        $statement->bindValue(1, $limit);
        $statement->execute();
        return $statement->fetchAll();
    }

    public function total(string $startDate, string $endDate): float
    {
        $statement = $this->db->prepare('SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE expense_date BETWEEN ? AND ?');
        $statement->execute([$startDate, $endDate]);
        return (float) $statement->fetchColumn();
    }

    public function create(array $data): bool
    {
        $statement = $this->db->prepare('INSERT INTO expenses (title, category, amount, paid_by, expense_date, note) VALUES (?, ?, ?, ?, ?, ?)');
        return $statement->execute([$data['title'], $data['category'], $data['amount'], $data['paid_by'], $data['expense_date'], $data['note']]);
    }
}
