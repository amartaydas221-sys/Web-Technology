<?php

class Deposit extends Model
{
    public function recent(int $limit = 10): array
    {
        $statement = $this->db->prepare(
            'SELECT deposits.*, users.name
             FROM deposits
             JOIN users ON users.id = deposits.user_id
             ORDER BY deposit_date DESC, deposits.id DESC
             LIMIT ?'
        );
        $statement->bindValue(1, $limit);
        $statement->execute();
        return $statement->fetchAll();
    }

    public function total(string $startDate, string $endDate): float
    {
        $statement = $this->db->prepare('SELECT COALESCE(SUM(amount), 0) FROM deposits WHERE deposit_date BETWEEN ? AND ?');
        $statement->execute([$startDate, $endDate]);
        return (float) $statement->fetchColumn();
    }

    public function create(int $userId, float $amount, string $date, string $note = ''): bool
    {
        $statement = $this->db->prepare('INSERT INTO deposits (user_id, amount, deposit_date, note) VALUES (?, ?, ?, ?)');
        return $statement->execute([$userId, $amount, $date, $note]);
    }

    public function memberBalances(string $startDate, string $endDate, float $perMealCost): array
    {
        $statement = $this->db->prepare(
            'SELECT users.id, users.name, users.email,
                    COALESCE(meal_totals.total_meals, 0) AS total_meals,
                    COALESCE(deposit_totals.total_deposits, 0) AS total_deposits
             FROM users
             LEFT JOIN (
                 SELECT user_id, SUM(breakfast + lunch + dinner) AS total_meals
                 FROM meals
                 WHERE meal_date BETWEEN ? AND ?
                 GROUP BY user_id
             ) meal_totals ON meal_totals.user_id = users.id
             LEFT JOIN (
                 SELECT user_id, SUM(amount) AS total_deposits
                 FROM deposits
                 WHERE deposit_date BETWEEN ? AND ?
                 GROUP BY user_id
             ) deposit_totals ON deposit_totals.user_id = users.id
             ORDER BY users.name'
        );
        $statement->execute([$startDate, $endDate, $startDate, $endDate]);
        $balances = [];

        foreach ($statement->fetchAll() as $member) {
            $member['meal_cost'] = (float) $member['total_meals'] * $perMealCost;
            $member['balance'] = (float) $member['total_deposits'] - $member['meal_cost'];
            $balances[] = $member;
        }

        return $balances;
    }
}
