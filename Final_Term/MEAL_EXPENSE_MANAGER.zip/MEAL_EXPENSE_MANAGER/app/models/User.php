<?php

class User extends Model
{
    public function all(): array
    {
        return $this->db->query('SELECT * FROM users ORDER BY name')->fetchAll();
    }

    public function find(int $id): ?array
    {
        $statement = $this->db->prepare('SELECT * FROM users WHERE id = ?');
        $statement->execute([$id]);
        return $statement->fetch() ?: null;
    }

    public function create(string $name, string $email, string $password): bool
    {
        $statement = $this->db->prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)');
        return $statement->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
    }

    public function authenticate(string $email, string $password): ?array
    {
        $statement = $this->db->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $statement->execute([$email]);
        $user = $statement->fetch();
        return $user && password_verify($password, $user['password']) ? $user : null;
    }
}
