<aside class="sidebar">
    <a class="brand" href="<?= APPURL ?>/?url=dashboard"><span class="brand-mark">M</span><span>MESS<br>MANAGER</span></a>
    <div class="workspace-label">Workspace</div>
    <nav class="nav-list">
        <a class="nav-item active" href="<?= APPURL ?>/?url=dashboard"><span class="nav-icon">⌂</span><span>Dashboard</span></a>
        <a class="nav-item" href="<?= APPURL ?>/?url=member"><span class="nav-icon">♙</span><span>Members</span></a>
        <a class="nav-item" href="<?= APPURL ?>/?url=meal"><span class="nav-icon">◈</span><span>Meals</span></a>
        <a class="nav-item" href="<?= APPURL ?>/?url=expense"><span class="nav-icon">৳</span><span>Expenses</span></a>
        <a class="nav-item" href="<?= APPURL ?>/?url=deposit"><span class="nav-icon">↓</span><span>Deposits</span></a>
        <a class="nav-item" href="<?= APPURL ?>/?url=report"><span class="nav-icon">▥</span><span>Reports</span></a>
        <a class="nav-item" href="<?= APPURL ?>/?url=member"><span class="nav-icon">⚙</span><span>Management</span></a>
    </nav>
    <div class="sidebar-footer"><a class="nav-item" href="<?= APPURL ?>/?url=auth/logout"><span class="nav-icon">↪</span><span>Logout</span></a><span class="status-dot"></span> Local workspace<br><small>Database connected</small></div>
</aside>
<main class="main-content">
    <header class="topbar"><div><span class="breadcrumb">Mess Manager /</span><h1><?= htmlspecialchars($title ?? 'Dashboard') ?></h1></div><div class="top-actions"><span class="notification">♧</span><div class="profile-chip"><span class="avatar">AU</span><span>Admin User</span></div></div></header>
