<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($title ?? SITENAME) ?> | <?= SITENAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600;700&family=Outfit:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= APPURL ?>/assets/css/style.css">
</head>

<body>
    <div class="login-page">
        <section class="login-brand">
            <span class="brand">
                <span class="brand-mark">M</span>
                <span>MESS MANAGER</span>
            </span>

            <span class="eyebrow" style="color: #4ade80; margin-top: 70px">
                Shared living, simplified
            </span>

            <h1>
                Meals counted.<br>
                Money settled.
            </h1>

            <p>
                A clearer way for roommates and mess members to manage daily meals,
                bazar expenses, and monthly dues.
            </p>
        </section>

        <section class="login-card">
            <span class="eyebrow">Welcome back</span>
            <h1>Sign in to your mess</h1>
            <p class="muted">Use your email to access the shared ledger.</p>

            <?php if (!empty($error)): ?>
                <p class="login-error">
                    <?= htmlspecialchars($error) ?>
                </p>
            <?php endif; ?>

            <form method="post" action="<?= APPURL ?>/?url=auth/authenticate">
                <label>
                    Email
                    <input
                        type="email"
                        name="email"
                        value="admin@example.com"
                        required>
                </label>

                <label>
                    Password
                    <input
                        type="password"
                        name="password"
                        value="password"
                        required>
                </label>

                <button class="button button-green" type="submit">
                    Continue <span>→</span>
                </button>
            </form>

            <small class="form-hint">
                Demo access: admin@example.com / password
            </small>
        </section>
    </div>
</body>

</html>