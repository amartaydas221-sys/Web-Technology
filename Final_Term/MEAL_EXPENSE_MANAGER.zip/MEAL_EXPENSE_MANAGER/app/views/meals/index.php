<?php
require APPROOT . '/views/layouts/header.php';
require APPROOT . '/views/layouts/sidebar.php';
?>

<section class="content-wrap">
    <div class="welcome-row">
        <div>
            <span class="eyebrow">Daily tracking</span>
            <h2>Meal sheet</h2>
        </div>
    </div>

    <section class="panel form-card">
        <form method="post" action="<?= APPURL ?>/?url=meal/save" data-ajax>
            <div class="form-grid">
                <label>
                    Member
                    <select name="user_id">
                        <?php foreach ($members as $member): ?>
                            <option value="<?= $member['id'] ?>">
                                <?= htmlspecialchars($member['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>
                    Date
                    <input type="date" name="meal_date" value="<?= date('Y-m-d') ?>" required>
                </label>
            </div>

            <div class="check-row">
                <label><input type="checkbox" name="meals[breakfast]" value="1"> Breakfast</label>
                <label><input type="checkbox" name="meals[lunch]" value="1"> Lunch</label>
                <label><input type="checkbox" name="meals[dinner]" value="1"> Dinner</label>
            </div>

            <label>
                Note
                <input name="note" placeholder="Optional note">
            </label>

            <button class="button button-dark" type="submit">Save meal entry</button>
        </form>
    </section>

    <section class="panel" style="margin-top: 15px">
        <div class="panel-heading">
            <h3>Recent meal entries</h3>
        </div>

        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Member</th>
                        <th>Breakfast</th>
                        <th>Lunch</th>
                        <th>Dinner</th>
                        <th>Admin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($meals as $meal): ?>
                        <tr>
                            <td><?= htmlspecialchars($meal['meal_date']) ?></td>
                            <td><?= htmlspecialchars($meal['name']) ?></td>
                            <td><?= $meal['breakfast'] ? 'Yes' : '-' ?></td>
                            <td><?= $meal['lunch'] ? 'Yes' : '-' ?></td>
                            <td><?= $meal['dinner'] ? 'Yes' : '-' ?></td>
                            <td>
                                <form method="post" action="<?= APPURL ?>/?url=meal/delete" data-ajax data-confirm="Remove this meal entry?">
                                    <input type="hidden" name="id" value="<?= (int) $meal['id'] ?>">
                                    <button class="button button-danger" type="submit">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</section>

<?php require APPROOT . '/views/layouts/footer.php'; ?>