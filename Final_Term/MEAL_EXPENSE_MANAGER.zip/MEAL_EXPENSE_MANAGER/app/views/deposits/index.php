<?php
require APPROOT . '/views/layouts/header.php';
require APPROOT . '/views/layouts/sidebar.php';
?>

<section class="content-wrap">
    <div class="welcome-row">
        <div>
            <span class="eyebrow">Collected funds</span>
            <h2>Deposit ledger</h2>
            <p class="muted" style="margin-top: 6px">
                <?= htmlspecialchars($month['label']) ?>
                · Per meal cost: ৳<?= number_format($perMealCost, 2) ?>
            </p>
        </div>
    </div>

    <section class="panel form-card">
        <div class="panel-heading">
            <div>
                <span class="eyebrow">Add money</span>
                <h3><?= $isAdmin ? 'Record a member deposit' : 'Add money to your account' ?></h3>
            </div>
        </div>

        <form method="post" action="<?= APPURL ?>/?url=deposit/save" data-ajax>
            <div class="form-grid">
                <?php if ($isAdmin): ?>
                    <label>
                        Member
                        <select name="user_id">
                            <?php foreach ($members as $member): ?>
                                <option value="<?= $member['id'] ?>">
                                    <?= htmlspecialchars($member['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                <?php else: ?>
                    <label>
                        Member
                        <input value="Your account" readonly>
                        <input type="hidden" name="user_id" value="<?= $currentUserId ?>">
                    </label>
                <?php endif; ?>

                <label>
                    Amount
                    <input type="number" step="0.01" min="0.01" name="amount" placeholder="0.00" required>
                </label>

                <label>
                    Date
                    <input type="date" name="deposit_date" value="<?= date('Y-m-d') ?>" required>
                </label>

                <label>
                    Note
                    <input name="note" placeholder="Optional note">
                </label>
            </div>

            <button class="button button-green" type="submit">Add deposit</button>
        </form>
    </section>

    <section class="panel" style="margin-top: 15px">
        <div class="panel-heading">
            <div>
                <span class="eyebrow">Settlement view</span>
                <h3>Remaining money and due money</h3>
            </div>
        </div>

        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>Member</th>
                        <th>Total meals</th>
                        <th>Meal cost</th>
                        <th>Deposited</th>
                        <th>Status</th>
                        <th>Balance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($balances as $balance): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($balance['name']) ?></strong>
                                <small><?= htmlspecialchars($balance['email']) ?></small>
                            </td>
                            <td><?= number_format((int) $balance['total_meals']) ?></td>
                            <td class="amount">৳<?= number_format($balance['meal_cost'], 2) ?></td>
                            <td class="amount">৳<?= number_format((float) $balance['total_deposits'], 2) ?></td>
                            <td>
                                <span class="balance-badge <?= $balance['balance'] >= 0 ? 'positive-badge' : 'negative-badge' ?>">
                                    <?= $balance['balance'] >= 0 ? 'Remaining' : 'Due' ?>
                                </span>
                            </td>
                            <td class="amount <?= $balance['balance'] >= 0 ? 'positive' : 'negative' ?>">
                                ৳<?= number_format(abs($balance['balance']), 2) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>

    <section class="panel" style="margin-top: 15px">
        <div class="panel-heading">
            <h3>Recent deposits</h3>
        </div>

        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>Member</th>
                        <th>Date</th>
                        <th>Note</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($deposits as $deposit): ?>
                        <tr>
                            <td><?= htmlspecialchars($deposit['name']) ?></td>
                            <td><?= htmlspecialchars($deposit['deposit_date']) ?></td>
                            <td><?= htmlspecialchars($deposit['note'] ?? '-') ?></td>
                            <td class="amount">৳<?= number_format((float) $deposit['amount'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</section>

<?php require APPROOT . '/views/layouts/footer.php'; ?>