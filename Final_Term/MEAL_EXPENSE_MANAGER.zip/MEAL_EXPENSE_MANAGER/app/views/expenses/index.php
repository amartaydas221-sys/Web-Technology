<?php
require APPROOT . '/views/layouts/header.php';
require APPROOT . '/views/layouts/sidebar.php';
?>

<section class="content-wrap">
    <div class="welcome-row">
        <div>
            <span class="eyebrow">Shared spending</span>
            <h2>Expense register</h2>
        </div>
    </div>

    <section class="panel form-card">
        <form method="post" action="<?= APPURL ?>/?url=expense/save" data-ajax>
            <div class="form-grid">
                <label>
                    Description
                    <input name="title" placeholder="e.g. Weekly groceries" required>
                </label>

                <label>
                    Amount
                    <input type="number" step="0.01" min="0" name="amount" placeholder="0.00" required>
                </label>

                <label>
                    Category
                    <select name="category">
                        <option>Bazaar</option>
                        <option>Utilities</option>
                        <option>Rent</option>
                        <option>Other</option>
                    </select>
                </label>

                <label>
                    Paid by
                    <select name="paid_by">
                        <?php foreach ($members as $member): ?>
                            <option value="<?= $member['id'] ?>">
                                <?= htmlspecialchars($member['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>
                    Date
                    <input type="date" name="expense_date" value="<?= date('Y-m-d') ?>" required>
                </label>

                <label>
                    Note
                    <input name="note" placeholder="Optional note">
                </label>
            </div>

            <button class="button button-dark" type="submit">Add expense</button>
        </form>
    </section>

    <section class="panel" style="margin-top: 15px">
        <div class="panel-heading">
            <h3>Recent expenses</h3>
        </div>

        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Paid by</th>
                        <th>Date</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($expenses as $expense): ?>
                        <tr>
                            <td><?= htmlspecialchars($expense['title']) ?></td>
                            <td><?= htmlspecialchars($expense['category']) ?></td>
                            <td><?= htmlspecialchars($expense['payer']) ?></td>
                            <td><?= htmlspecialchars($expense['expense_date']) ?></td>
                            <td class="amount">
                                ৳<?= number_format((float) $expense['amount'], 2) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</section>

<?php require APPROOT . '/views/layouts/footer.php'; ?>