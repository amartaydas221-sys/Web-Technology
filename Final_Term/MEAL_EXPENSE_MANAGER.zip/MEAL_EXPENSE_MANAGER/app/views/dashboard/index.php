<?php
require APPROOT . '/views/layouts/header.php';
require APPROOT . '/views/layouts/sidebar.php';
?>

<section class="content-wrap">
    <div class="welcome-row">
        <div>
            <p class="muted">Tuesday, <?= date('F j, Y') ?></p>
            <h2>Good morning, Admin</h2>
        </div>
        <a class="button button-green" href="<?= APPURL ?>/?url=meal">
            + Enter tomorrow's meal
        </a>
    </div>

    <section class="hero-banner">
        <div>
            <span class="eyebrow">Tomorrow's kitchen plan</span>
            <h2>Every meal counted. Every expense clear.</h2>
            <p>
                Keep the household running smoothly by logging meals before the 9 PM cutoff.
            </p>
            <a
                class="button button-green"
                style="margin-top: 15px"
                href="<?= htmlspecialchars($chefWhatsappUrl) ?>"
                target="_blank"
                rel="noopener">
                Send count to chef via WhatsApp
            </a>
        </div>

        <div class="hero-metric">
            <span class="eyebrow">Tomorrow's total meals</span>
            <strong><?= number_format($tomorrowMeals) ?></strong>
        </div>
    </section>

    <div class="stat-grid">
        <article class="stat-card accent">
            <span class="stat-label">Total meals</span>
            <strong><?= number_format($stats['meals']) ?></strong>
            <span class="stat-note">This month</span>
        </article>

        <article class="stat-card">
            <span class="stat-label">Total bazar</span>
            <strong>৳<?= number_format($stats['expenses'], 2) ?></strong>
            <span class="stat-note">Shared expenses</span>
        </article>

        <article class="stat-card">
            <span class="stat-label">Per meal cost</span>
            <strong>
                ৳<?= number_format($stats['meals'] ? $stats['expenses'] / $stats['meals'] : 0, 2) ?>
            </strong>
            <span class="stat-note">Live calculated</span>
        </article>

        <article class="stat-card warning">
            <span class="stat-label">Days remaining</span>
            <strong><?= max(0, (int) date('t') - (int) date('j')) ?></strong>
            <span class="stat-note">In <?= htmlspecialchars($month['label']) ?></span>
        </article>
    </div>

    <div class="dashboard-grid">
        <section class="panel wide-panel">
            <div class="panel-heading">
                <div>
                    <span class="eyebrow">Quick entry</span>
                    <h3>Enter your meal for tomorrow</h3>
                </div>
                <span class="eyebrow">Cutoff 9:00 PM</span>
            </div>

            <div class="meal-quick">
                <div>
                    <p class="muted">How many meals will you eat?</p>
                    <div class="stepper">
                        <button type="button">−</button>
                        <strong>2</strong>
                        <button type="button">+</button>
                    </div>
                    <a class="button button-green" href="<?= APPURL ?>/?url=meal">
                        Lock in my meal
                    </a>
                </div>

                <div class="dark-panel" style="padding: 18px; min-width: 160px">
                    <span class="eyebrow">Tomorrow</span>
                    <h3 style="margin: 9px 0 0">Wednesday</h3>
                    <p style="margin-top: 6px">Your entry is ready.</p>
                </div>
            </div>
        </section>

        <section class="panel">
            <span class="eyebrow">My account</span>
            <h3 style="margin-top: 5px">Current balance</h3>
            <div class="balance-number positive">
                ৳<?= number_format($stats['deposits'] - ($stats['meals'] ? $stats['expenses'] : 0), 2) ?>
            </div>
            <p class="muted">Advance balance</p>
            <div class="progress" style="margin-top: 18px">
                <span style="width: 68%"></span>
            </div>
            <p class="muted" style="margin-top: 8px">68% of expected deposit</p>
        </section>

        <section class="panel">
            <span class="eyebrow">Household</span>
            <h3 style="margin-top: 5px">Member balances</h3>
            <div style="margin-top: 18px">
                <p>
                    <strong>Admin User</strong>
                    <span style="float: right" class="positive">৳1,240</span>
                </p>
                <div class="progress" style="margin-top: 8px">
                    <span style="width: 76%"></span>
                </div>
                <p style="margin-top: 15px">
                    <strong>Members</strong>
                    <span style="float: right" class="muted"><?= count($members) ?> active</span>
                </p>
            </div>
        </section>
    </div>

    <div class="section-grid">
        <section class="panel">
            <div class="panel-heading">
                <div>
                    <span class="eyebrow">Latest activity</span>
                    <h3>Recent expenses</h3>
                </div>
                <a class="text-link" href="<?= APPURL ?>/?url=expense">
                    View all →
                </a>
            </div>

            <?php if (!$expenses): ?>
                <div class="empty-state">
                    No expenses logged yet. Add the first shared purchase.
                </div>
            <?php else: ?>
                <div class="table-scroll">
                    <table>
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Paid by</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($expenses as $expense): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($expense['title']) ?></strong>
                                        <small><?= htmlspecialchars($expense['category']) ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($expense['payer']) ?></td>
                                    <td class="amount">
                                        ৳<?= number_format((float) $expense['amount'], 2) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

        <section class="panel dark-panel">
            <span class="eyebrow">Household pulse</span>
            <h3>
                Keep the ledger<br>
                clear and current.
            </h3>
            <p>Log meals daily and settle balances at the end of each month.</p>
            <div class="pulse-line">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
            <a class="button button-light" href="<?= APPURL ?>/?url=report">
                Open report
            </a>
        </section>
    </div>
</section>

<?php require APPROOT . '/views/layouts/footer.php'; ?>